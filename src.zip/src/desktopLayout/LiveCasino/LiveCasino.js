import React from "react";
import NewLunch from "../Newlunch/NewLunch";
import SideBar from "../sidebar/SideBar";

const LiveCasino = () => {
  return (
    <>
      <div className="main">
        <div className="container-fluid container-fluid-5">
          <div className=" itemHome">
              <NewLunch/>
          </div>
        </div>
      </div>

    </>
  );
};

export default LiveCasino;
