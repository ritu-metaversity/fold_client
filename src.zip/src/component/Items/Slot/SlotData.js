import React from 'react'
import Mobilenav from '../../navBar/MobileNav/Mobilenav'
import Slot from './Slot'

const SlotData = () => {
  return (
    <>
    <div>
        <Mobilenav/>
    </div>
    <Slot/>
    </>
  )
}

export default SlotData